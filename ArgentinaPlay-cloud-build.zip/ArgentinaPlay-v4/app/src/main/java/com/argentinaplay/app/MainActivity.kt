package com.argentinaplay.app

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ActivityCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private data class Channel(
    val name: String,
    val category: String,
    val officialUrl: String,
    val streamUrl: String? = null,
    val emoji: String = "📺",
    val description: String = "Transmisión pública o autorizada"
)

class MainActivity : Activity() {
    private val bg = Color.rgb(4, 8, 15)
    private val surface = Color.rgb(14, 24, 38)
    private val surface2 = Color.rgb(20, 34, 52)
    private val blue = Color.rgb(0, 153, 255)
    private val cyan = Color.rgb(55, 220, 255)
    private val white = Color.WHITE
    private val prefs by lazy { getSharedPreferences("argentina_play", Context.MODE_PRIVATE) }
    private var player: ExoPlayer? = null
    private val notificationChannelId = "argentina_play_news"
    private val notificationEnabledKey = "notifications_enabled"

    private val channels = listOf(
        Channel("TV Pública", "Noticias", "https://www.tvpublica.com.ar/vivo", null, "🇦🇷", "Señal oficial"),
        Channel("Canal 26", "Noticias", "https://www.canal26.com/canal26-en-vivo/", null, "📰", "Señal oficial"),
        Channel("Canal oficial", "Noticias", "https://www.youtube.com/", null, "▶️", "Fuente oficial"),
        Channel("Música", "Música", "https://www.youtube.com/", null, "🎵", "Contenido oficial"),
        Channel("Deportes", "Deportes", "https://www.youtube.com/", null, "⚽", "Contenido oficial")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf("android.permission.POST_NOTIFICATIONS"), 2001)
        }
        showHome()
    }
    override fun onStop() { super.onStop(); releasePlayer() }

    private fun showHome() {
        val root = baseRoot()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 10, 18, 18) }
        content.addView(header())
        content.addView(hero())
        sectionTitle(content, "Canales en vivo", "Ver ahora") { showChannels("Todos") }
        content.addView(channelStrip(channels.take(4)))
        sectionTitle(content, "Explorá por categoría", "") { }
        content.addView(categoryGrid())
        sectionTitle(content, "Mis favoritos", "Ver todos") { showFavorites() }
        content.addView(favoritePreview())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar())
        setContentView(root)
    }

    private fun baseRoot() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }

    private fun header(): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(2, 10, 2, 12)
        val brand = TextView(this@MainActivity).apply { text = "Argentina Play"; textSize = 27f; setTextColor(white); setTypeface(null, 1) }
        addView(brand, LinearLayout.LayoutParams(0, 58, 1f))
        addView(iconButton("⌕") { showSearch() }, LinearLayout.LayoutParams(52, 52))
        addView(iconButton("⚙") { showSettings() }, LinearLayout.LayoutParams(52, 52).apply { setMargins(6,0,0,0) })
    }

    private fun hero(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(24, 22, 20, 20)
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(0,102,204), Color.rgb(8,24,42))).apply { cornerRadius = 32f }
        layoutParams = LinearLayout.LayoutParams(-1, 220).apply { setMargins(0, 4, 0, 12) }
        addView(TextView(this@MainActivity).apply { text = "🔴  EN VIVO"; textSize = 14f; setTextColor(cyan); setTypeface(null,1) })
        addView(TextView(this@MainActivity).apply { text = "Tu TV, siempre gratis"; textSize = 28f; setTextColor(white); setTypeface(null,1); setPadding(0,8,0,4) })
        addView(TextView(this@MainActivity).apply { text = "Canales públicos y fuentes autorizadas en un solo lugar."; textSize = 14f; setTextColor(Color.rgb(220,235,250)) })
        addView(Button(this@MainActivity).apply { text = "▶  Ver TV en vivo"; textSize = 14f; setTextColor(white); background = rounded(Color.rgb(8,55,100), 18f); setOnClickListener { showChannels("Todos") } }, LinearLayout.LayoutParams(-2,54).apply { setMargins(0,14,0,0) })
    }

    private fun sectionTitle(parent: LinearLayout, title: String, action: String, onClick: () -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(2, 12, 2, 8) }
        row.addView(TextView(this).apply { text = title; textSize = 20f; setTextColor(white); setTypeface(null,1) }, LinearLayout.LayoutParams(0,50,1f))
        if (action.isNotEmpty()) row.addView(TextView(this).apply { text = action; textSize=13f; setTextColor(cyan); setOnClickListener{onClick()} })
        parent.addView(row)
    }

    private fun channelStrip(list: List<Channel>): View = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            list.forEach { ch -> addView(channelCard(ch), LinearLayout.LayoutParams(178, 160).apply { setMargins(0,0,10,4) }) }
        })
    }

    private fun channelCard(ch: Channel): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(10,10,10,10); background=rounded(surface,22f)
        addView(TextView(this@MainActivity).apply { text=ch.emoji; textSize=31f; gravity=Gravity.CENTER })
        addView(TextView(this@MainActivity).apply { text=ch.name; textSize=15f; setTextColor(white); setTypeface(null,1); gravity=Gravity.CENTER; setPadding(0,5,0,2) })
        addView(TextView(this@MainActivity).apply { text="● EN VIVO"; textSize=11f; setTextColor(cyan); gravity=Gravity.CENTER })
        setOnClickListener { playChannel(ch) }
        setOnLongClickListener { toggleFavorite(ch.name); Toast.makeText(this@MainActivity, if(isFavorite(ch.name)) "Agregado a favoritos" else "Quitado de favoritos", Toast.LENGTH_SHORT).show(); true }
    }

    private fun categoryGrid(): View = GridLayout(this).apply {
        columnCount=2; rowCount=2
        listOf("📰  Noticias" to "Noticias", "⚽  Deportes" to "Deportes", "🎬  Entretenimiento" to "Entretenimiento", "🎵  Música" to "Música").forEach { (label, cat) ->
            addView(TextView(this@MainActivity).apply { text=label; textSize=15f; setTextColor(white); gravity=Gravity.CENTER; background=rounded(surface,20f); setOnClickListener{showChannels(cat)} }, GridLayout.LayoutParams().apply{width=0;height=88;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(0,0,8,8)})
        }
    }

    private fun favoritePreview(): View {
        val favs = channels.filter { isFavorite(it.name) }
        return if (favs.isEmpty()) TextView(this).apply { text="Todavía no tenés favoritos.\nMantené presionado un canal para guardarlo."; textSize=14f; setTextColor(Color.GRAY); setPadding(4,6,4,18) }
        else channelStrip(favs.take(3))
    }

    private fun bottomBar(): View = LinearLayout(this).apply {
        orientation=LinearLayout.HORIZONTAL; setBackgroundColor(Color.rgb(7,14,23)); setPadding(3,5,3,5)
        listOf("⌂\nInicio" to {showHome()}, "▣\nEn vivo" to {showChannels("Todos")}, "★\nFavoritos" to {showFavorites()}, "⌕\nBuscar" to {showSearch()}, "☰\nMás" to {showSettings()}).forEach { (label, action) ->
            addView(TextView(this@MainActivity).apply { text=label; gravity=Gravity.CENTER; textSize=12f; setTextColor(Color.LTGRAY); setOnClickListener{action()} }, LinearLayout.LayoutParams(0,64,1f))
        }
    }

    private fun showChannels(category: String) {
        val list = if (category=="Todos") channels else channels.filter{it.category==category}
        val root=baseRoot(); val scroll=ScrollView(this); val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,20,18,24)}
        content.addView(pageTitle("TV en vivo", "Elegí un canal para comenzar a mirar."))
        list.forEach { ch -> content.addView(channelRow(ch)) }
        content.addView(infoText("Los streams directos solo deben cargarse cuando sean públicos o exista autorización para su distribución."))
        content.addView(backButton()); scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }

    private fun channelRow(ch: Channel): View = LinearLayout(this).apply {
        orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(14,10,10,10); background=rounded(surface,20f); setOnClickListener{playChannel(ch)}
        addView(TextView(this@MainActivity).apply{text=ch.emoji;textSize=28f;gravity=Gravity.CENTER},LinearLayout.LayoutParams(58,70))
        addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL; addView(TextView(this@MainActivity).apply{text=ch.name;textSize=16f;setTextColor(white);setTypeface(null,1)});addView(TextView(this@MainActivity).apply{text="● EN VIVO  •  ${ch.description}";textSize=12f;setTextColor(cyan);setPadding(0,5,0,0)})},LinearLayout.LayoutParams(0,70,1f))
        addView(TextView(this@MainActivity).apply{text=if(isFavorite(ch.name))"★" else "☆";textSize=24f;setTextColor(cyan);setOnClickListener{toggleFavorite(ch.name);showChannels(category)}},LinearLayout.LayoutParams(45,70))
        layoutParams=LinearLayout.LayoutParams(-1,90).apply{setMargins(0,0,0,10)}
    }

    private fun playChannel(ch: Channel) {
        if (ch.streamUrl.isNullOrBlank()) { openOfficial(ch); return }
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.BLACK)}
        val playerView=PlayerView(this).apply{useController=true;keepScreenOn=true}
        root.addView(playerView,LinearLayout.LayoutParams(-1,0,1f)); root.addView(TextView(this).apply{text="‹  ${ch.name}";textSize=18f;setTextColor(white);setPadding(18,16,10,16);setOnClickListener{releasePlayer();showHome()}},LinearLayout.LayoutParams(-1,60))
        setContentView(root); releasePlayer(); player=ExoPlayer.Builder(this).build(); playerView.player=player; player!!.setMediaItem(MediaItem.fromUri(ch.streamUrl));player!!.prepare();player!!.play()
    }

    private fun openOfficial(ch: Channel) {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.BLACK)}
        root.addView(TextView(this).apply{text="‹  ${ch.name}";textSize=19f;setTextColor(white);setPadding(18,18,10,18);setOnClickListener{showChannels("Todos")}},LinearLayout.LayoutParams(-1,64))
        val web=WebView(this).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.mediaPlaybackRequiresUserGesture=false;webViewClient=WebViewClient();webChromeClient=WebChromeClient();loadUrl(ch.officialUrl)}
        root.addView(web,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
    }

    private fun showFavorites() {
        val favs=channels.filter{isFavorite(it.name)}; val root=baseRoot(); val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,20,18,20)}
        content.addView(pageTitle("Mis favoritos", "Tus canales guardados."))
        if(favs.isEmpty()) content.addView(infoText("No hay favoritos todavía.")) else favs.forEach{content.addView(channelRow(it))}
        content.addView(backButton());root.addView(content);setContentView(root)
    }

    private fun showSearch() {
        val root=baseRoot(); val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,20,18,20)}
        content.addView(pageTitle("Buscar", "Encontrá canales por nombre o categoría."))
        val input=EditText(this).apply{hint="Buscar…";setHintTextColor(Color.GRAY);setTextColor(white);setSingleLine=true;setPadding(18,0,18,0);background=rounded(surface,18f)}
        content.addView(input,LinearLayout.LayoutParams(-1,58).apply{setMargins(0,0,0,14)});val results=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(results)
        fun render(){results.removeAllViews();channels.filter{it.name.contains(input.text.toString(),true)||it.category.contains(input.text.toString(),true)}.forEach{results.addView(channelRow(it))}}
        input.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()};override fun afterTextChanged(e:android.text.Editable?){}});render();content.addView(backButton());root.addView(content);setContentView(root);input.requestFocus()
    }

    private fun showSettings() {
        val root=baseRoot();val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,24,20,20)}
        content.addView(pageTitle("Más", "Configuración de Argentina Play."))
        content.addView(setting("⭐  Favoritos guardados", "${channels.count{isFavorite(it.name)}} canales"))
        content.addView(Button(this).apply{text="Borrar todos los favoritos";setTextColor(white);background=rounded(surface,18f);setOnClickListener{prefs.edit().clear().apply();Toast.makeText(this@MainActivity,"Favoritos borrados",Toast.LENGTH_SHORT).show();showSettings()}})
        content.addView(setting("📺  Reproducción", "Media3 / ExoPlayer para streams directos autorizados"))
        content.addView(setting("🔐  Contenido", "Solo fuentes públicas o con permiso de distribución"))
        content.addView(setting("🔔  Notificaciones", if (notificationsEnabled()) "Activadas" else "Desactivadas"))
        content.addView(Button(this).apply {
            text = if (notificationsEnabled()) "Desactivar notificaciones" else "Activar notificaciones"
            setTextColor(white); background = rounded(surface, 18f)
            setOnClickListener {
                prefs.edit().putBoolean(notificationEnabledKey, !notificationsEnabled()).apply()
                if (notificationsEnabled()) sendNotification("Argentina Play", "¡Las notificaciones están activadas!")
                showSettings()
            }
        })
        content.addView(Button(this).apply {
            text = "Enviar notificación de prueba"; setTextColor(white); background = rounded(surface, 18f)
            setOnClickListener { sendNotification("Argentina Play", "Notificación de prueba funcionando correctamente 🔔") }
        })
        content.addView(setting("ℹ️  Versión", "Argentina Play 1.0.0"))
        content.addView(backButton());root.addView(content);setContentView(root)
    }

    private fun setting(title:String,sub:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,14,16,14);background=rounded(surface,18f);addView(TextView(this@MainActivity).apply{text=title;textSize=16f;setTextColor(white);setTypeface(null,1)});addView(TextView(this@MainActivity).apply{text=sub;textSize=12f;setTextColor(Color.GRAY);setPadding(0,5,0,0)});layoutParams=LinearLayout.LayoutParams(-1,82).apply{setMargins(0,0,0,10)}}
    private fun pageTitle(title:String,sub:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;addView(TextView(this@MainActivity).apply{text=title;textSize=29f;setTextColor(white);setTypeface(null,1)});addView(TextView(this@MainActivity).apply{text=sub;textSize=14f;setTextColor(Color.GRAY);setPadding(0,7,0,20)})}
    private fun infoText(text:String)=TextView(this).apply{this.text=text;textSize=13f;setTextColor(Color.GRAY);setPadding(3,14,3,14)}
    private fun backButton()=Button(this).apply{text="‹  Volver al inicio";textSize=14f;setTextColor(white);background=rounded(blue,18f);setOnClickListener{showHome()};layoutParams=LinearLayout.LayoutParams(-1,56).apply{setMargins(0,18,0,0)}}
    private fun iconButton(text:String,onClick:()->Unit)=TextView(this).apply{this.text=text;textSize=24f;gravity=Gravity.CENTER;setTextColor(white);background=rounded(surface,18f);setOnClickListener{onClick()}}
    private fun isFavorite(name:String)=prefs.getBoolean("fav_$name",false)
    private fun toggleFavorite(name:String){prefs.edit().putBoolean("fav_$name",!isFavorite(name)).apply()}
    private fun notificationsEnabled() = prefs.getBoolean(notificationEnabledKey, true)
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(notificationChannelId, "Argentina Play", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Novedades y transmisiones de Argentina Play"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun sendNotification(title: String, message: String) {
        if (!notificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permití las notificaciones desde Android para recibir avisos.", Toast.LENGTH_LONG).show(); return
        }
        val intent = PendingIntent.getActivity(this, 0, android.content.Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, notificationChannelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(message).setContentIntent(intent)
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }
    private fun releasePlayer(){player?.release();player=null}
    private fun rounded(color:Int,radius:Float)=GradientDrawable().apply{setColor(color);cornerRadius=radius}
}
