plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.argentinaplay.app"; compileSdk = 35
    defaultConfig { applicationId = "com.argentinaplay.app"; minSdk = 23; targetSdk = 35; versionCode = 4; versionName = "1.0.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.11.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")
}
